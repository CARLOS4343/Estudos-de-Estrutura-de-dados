package p1;

public interface Empilhavel {
	void empilhar(Object dado);
    Object desenpilhar();
    void atualizar(Object dado);
    boolean estacheio();
    boolean estavazio();
    String imprimir();
}
